const varaiables = {
    SERVER_URL: 'https://medical-ai-backend.onrender.com'
}

export default varaiables