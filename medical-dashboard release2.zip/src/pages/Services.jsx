import React from 'react'
import ServiceCard from '../components/cards/ServiceCard'

const services = [
  {
    name: "Paients History Management",
    icon: "",
    link: "/", 
    info: "Some Information"
  },
  {
    name: "Doctors Management",
    icon: "",
    link: "/", 
    info: "Some Information"
  },
  {
    name: "Colloborative Platform",
    icon: "",
    link: "/", 
    info: "Some Information"
  }
]

function Services() {
  return (
    <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 lg:gap-[30px] mt-[30px] lg:mt-[55px]'>
      {
        services.map((item, index) => <ServiceCard item={item} index={index}/>)
      }
    </div>
  )
}

export default Services