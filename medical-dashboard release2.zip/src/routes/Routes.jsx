import React from 'react'
import {Routes, Route} from 'react-router-dom'
import Home from '../pages/Home'
import Contact from '../pages/Contact'
import AboutUs from '../pages/AboutUs'
import Services from '../pages/Services'
import SignIn from '../pages/SignIn'
import SignUp from '../pages/SignUp'
import Doctors from '../pages/Doctors'
import DoctorDetails from '../pages/DoctorDetails'
import Profile from '../pages/profile/Profile'
import Appointments from '../pages/profile/Appointments'
import Records from '../pages/profile/Records'
import AppointmentForm from '../pages/AppointmentForm'
import MedicalRecords from '../pages/profile/MedicalRecords'

function Routings() {
  return (
    <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/home' element={<Home/>}/>
        <Route path='/contact-us' element={<Contact/>}/> 
        <Route path='/about-us' element={<AboutUs/>}/>
        <Route path='/services' element={<Services/>}/>
        <Route path='/signin' element={<SignIn/>}/>
        <Route path='/signup' element={<SignUp/>}/>
        <Route path='/doctors'>
            <Route path='' element={<Doctors/>}/>
            <Route path=':id' element={<DoctorDetails/>}/>
            <Route path=':id/:name' element={<AppointmentForm/>}/>
        </Route>
        <Route path='/profile'>
            <Route path='' element={<Profile/>}/>
            <Route path='appointments' element={<Appointments/>}/>
            <Route path='records' element={<Records/>}/>
            <Route path='medicalbook/:patient' element={<MedicalRecords/>}/>
        </Route>
        
    </Routes>
  )
}

export default Routings